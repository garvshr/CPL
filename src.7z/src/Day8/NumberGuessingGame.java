//package Day8;
//
//import java.util.*;
//public class NumberGuessingGame {
//
//    static int guessNumber() {
//        int number = (int) Math.random();
//    }
//
//    public static void main(String[] args) {
//
//        Scanner ob = new Scanner(System.in);
//        System.out.println("Input a number between 1 to 100");
//        int number = ob.nextInt();
//
//
//    }
//
//}
