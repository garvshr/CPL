package Array;

import java.util.Scanner;
public class BMI {

	public static void main(String args[]) {
		Scanner ob= new Scanner(System.in);
		
		
	}
	
}
