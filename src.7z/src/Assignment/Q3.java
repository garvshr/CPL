package Assignment;

public class Q3 {
	public static int method() {
		int count = 10;
		return count;
	}
	
	public static void main() {
		System.out.println(method());
	}
}
